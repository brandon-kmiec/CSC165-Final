/**
 * A physics wrapper for JBullet.
 *
 * @author Russell Bolles and Kyle Matz
 */
package tage.physics;