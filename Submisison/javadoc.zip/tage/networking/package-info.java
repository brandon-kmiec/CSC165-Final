/**
 * Classes for building application layer network protocols.
 *
 * @author Kyle Matz
 */
package tage.networking;